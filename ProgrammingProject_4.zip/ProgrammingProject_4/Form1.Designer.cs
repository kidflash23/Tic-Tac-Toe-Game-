﻿namespace ProgrammingProject_4
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.newGameButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.A00 = new System.Windows.Forms.Button();
            this.A03 = new System.Windows.Forms.Button();
            this.A06 = new System.Windows.Forms.Button();
            this.A07 = new System.Windows.Forms.Button();
            this.A04 = new System.Windows.Forms.Button();
            this.A01 = new System.Windows.Forms.Button();
            this.A02 = new System.Windows.Forms.Button();
            this.A05 = new System.Windows.Forms.Button();
            this.A08 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // newGameButton
            // 
            this.newGameButton.Location = new System.Drawing.Point(44, 426);
            this.newGameButton.Name = "newGameButton";
            this.newGameButton.Size = new System.Drawing.Size(75, 23);
            this.newGameButton.TabIndex = 0;
            this.newGameButton.Text = "New Game";
            this.newGameButton.UseVisualStyleBackColor = true;
            this.newGameButton.Click += new System.EventHandler(this.newGameButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(163, 426);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 1;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.button2_Click);
            // 
            // A00
            // 
            this.A00.Location = new System.Drawing.Point(257, 48);
            this.A00.Name = "A00";
            this.A00.Size = new System.Drawing.Size(123, 102);
            this.A00.TabIndex = 2;
            this.A00.UseVisualStyleBackColor = true;
            this.A00.Click += new System.EventHandler(this.buttonClick);
            // 
            // A03
            // 
            this.A03.Location = new System.Drawing.Point(257, 145);
            this.A03.Name = "A03";
            this.A03.Size = new System.Drawing.Size(123, 102);
            this.A03.TabIndex = 3;
            this.A03.UseVisualStyleBackColor = true;
            this.A03.Click += new System.EventHandler(this.buttonClick);
            // 
            // A06
            // 
            this.A06.Location = new System.Drawing.Point(257, 241);
            this.A06.Name = "A06";
            this.A06.Size = new System.Drawing.Size(123, 102);
            this.A06.TabIndex = 4;
            this.A06.UseVisualStyleBackColor = true;
            this.A06.Click += new System.EventHandler(this.buttonClick);
            // 
            // A07
            // 
            this.A07.Location = new System.Drawing.Point(374, 241);
            this.A07.Name = "A07";
            this.A07.Size = new System.Drawing.Size(123, 102);
            this.A07.TabIndex = 5;
            this.A07.UseVisualStyleBackColor = true;
            this.A07.Click += new System.EventHandler(this.buttonClick);
            // 
            // A04
            // 
            this.A04.Location = new System.Drawing.Point(374, 145);
            this.A04.Name = "A04";
            this.A04.Size = new System.Drawing.Size(123, 102);
            this.A04.TabIndex = 6;
            this.A04.UseVisualStyleBackColor = true;
            this.A04.Click += new System.EventHandler(this.buttonClick);
            // 
            // A01
            // 
            this.A01.Location = new System.Drawing.Point(374, 48);
            this.A01.Name = "A01";
            this.A01.Size = new System.Drawing.Size(123, 102);
            this.A01.TabIndex = 7;
            this.A01.UseVisualStyleBackColor = true;
            this.A01.Click += new System.EventHandler(this.buttonClick);
            // 
            // A02
            // 
            this.A02.Location = new System.Drawing.Point(494, 48);
            this.A02.Name = "A02";
            this.A02.Size = new System.Drawing.Size(123, 102);
            this.A02.TabIndex = 8;
            this.A02.UseVisualStyleBackColor = true;
            this.A02.Click += new System.EventHandler(this.buttonClick);
            // 
            // A05
            // 
            this.A05.Location = new System.Drawing.Point(494, 145);
            this.A05.Name = "A05";
            this.A05.Size = new System.Drawing.Size(123, 102);
            this.A05.TabIndex = 9;
            this.A05.UseVisualStyleBackColor = true;
            this.A05.Click += new System.EventHandler(this.buttonClick);
            // 
            // A08
            // 
            this.A08.Location = new System.Drawing.Point(494, 241);
            this.A08.Name = "A08";
            this.A08.Size = new System.Drawing.Size(123, 102);
            this.A08.TabIndex = 10;
            this.A08.UseVisualStyleBackColor = true;
            this.A08.Click += new System.EventHandler(this.buttonClick);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.GrayText;
            this.label1.Font = new System.Drawing.Font("Microsoft New Tai Lue", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.DarkRed;
            this.label1.Location = new System.Drawing.Point(475, 346);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(379, 168);
            this.label1.TabIndex = 11;
            this.label1.Text = resources.GetString("label1.Text");
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(855, 494);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.A08);
            this.Controls.Add(this.A05);
            this.Controls.Add(this.A02);
            this.Controls.Add(this.A01);
            this.Controls.Add(this.A04);
            this.Controls.Add(this.A07);
            this.Controls.Add(this.A06);
            this.Controls.Add(this.A03);
            this.Controls.Add(this.A00);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.newGameButton);
            this.Name = "Form1";
            this.Text = "Tic-Tac-Toe Simulator";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button newGameButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Button A00;
        private System.Windows.Forms.Button A03;
        private System.Windows.Forms.Button A06;
        private System.Windows.Forms.Button A07;
        private System.Windows.Forms.Button A04;
        private System.Windows.Forms.Button A01;
        private System.Windows.Forms.Button A02;
        private System.Windows.Forms.Button A05;
        private System.Windows.Forms.Button A08;
        private System.Windows.Forms.Label label1;
    }
}

