﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProgrammingProject_4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }


        public int participant = 2; // even is X turn and odd is O turn;
        public int rounds = 0;
        public int r1 = 0;
        public int r2 = 0;
        public int rd = 0;

        private void Form1_Load(object sender, EventArgs e) // this creates all of the forms controls.
        {
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void buttonClick(object sender, EventArgs e)
        {
            Button button = (Button)sender;
            if (button.Text == "")
            { 


                if (participant % 2 == 0)
                {
                    button.Text = "X";
                    participant++;
                    rounds++;

                }

                else
                {
                    button.Text = "O";
                    participant++;
                    rounds++;
                }
        }

                if (CheckDraw() == true)
            {
                MessageBox.Show("This is a TIE GAME!");
                    rd++;
                newGame();
            }

                if (CheckWin() == true)
            {
                if (button.Text == "X")
                {
                    MessageBox.Show("Congratulations X! You won the match!");
                    r1++;
                    newGame();

                }

                else
                {
                    MessageBox.Show("Congratulations Y! You won the match!");
                    r2++;
                    newGame();
                }
            }
        }

        void newGame()
        {
            participant = 2;
            rounds = 0;
            A00.Text = A01.Text = A02.Text = A03.Text = A04.Text = A05.Text = A06.Text = A07.Text = A08.Text = "";
        }

        private void newGameButton_Click(object sender, EventArgs e)
        {
            newGame();
        }

        bool CheckDraw()
        {
            if (rounds == 9)
                return true;
            else
                return false;
        }

        bool CheckWin()
        {
            // check the boxes horizontally
            if ((A00.Text == A01.Text) && (A01.Text == A02.Text) && A00.Text != "")
                return true;
            else if ((A03.Text == A04.Text) && (A04.Text == A05.Text) && A03.Text != "")
                return true;
            else if ((A06.Text == A07.Text) && (A07.Text == A08.Text) && A06.Text != "")
                return true;


            //check the boxes vertically
            if ((A00.Text == A03.Text) && (A03.Text == A06.Text) && A00.Text != "")
                return true;
            else if ((A01.Text == A04.Text) && (A04.Text == A07.Text) && A01.Text != "")
                return true;
            else if ((A02.Text == A05.Text) && (A05.Text == A08.Text) && A02.Text != "")
                return true;

            //check boxes diagnonally
            if ((A00.Text == A04.Text) && (A04.Text == A08.Text) && A00.Text != "")
                return true;
            else if ((A02.Text == A04.Text) && (A04.Text == A07.Text) && A02.Text != "")
                return true;

            else
                return false;


        }
    }
}
